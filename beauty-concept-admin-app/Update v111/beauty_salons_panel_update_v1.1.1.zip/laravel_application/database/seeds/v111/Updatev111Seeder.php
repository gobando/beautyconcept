<?php
/*
 * File name: Updatev111Seeder.php
 * Last modified: 2022.02.26 at 15:50:25
 * Author: SmarterVision - https://codecanyon.net/user/smartervision
 * Copyright (c) 2022
 */

use Illuminate\Database\Seeder;

class Updatev111Seeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
    }
}
